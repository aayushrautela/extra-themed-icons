# Extra Themed Icons (Fork)


This Magisk Module adds more icons either lines or filled (you can choose) than a normal Pixel Launcher.
For now choose lawnicons as its updated recently with way more icons.

![](https://raw.githubusercontent.com/syoker/extra-themed-icons/main/.github/img/image.png)

> **NOTES:**
>
> - These icons are not mine (the credits will be below, I only make the module).
> - I recommend disabling and enabling the thematic icons for the correct functioning of the module.


## Requirements

- Magisk

## Compatibility

- Android 12 on up


## Credits

- TeamFiles Icons by [TeamFiles](https://github.com/TeamFiles "Team Files")
- Lawnicons by [Lawnchair Team](https://github.com/LawnchairLauncher/lawnicons "Lawnchair News")
- Syoker for the initial module
