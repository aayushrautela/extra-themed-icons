### v10.0
- Added 318 Lawnicons by [Lawnchair Team](https://github.com/LawnchairLauncher/lawnicons "Lawnchair GitHub") and added 69 TeamFiles Icons by [TeamFiles](https://github.com/TeamFiles "Team Files") | [New icons here](https://github.com/Syoker/ExtraThemedIcons/blob/main/newicons.md#v100 "New icons for version v10.0")

### Notes
- I recommend disabling and enabling the thematic icons so that the module is well applied.