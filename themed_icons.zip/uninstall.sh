
  rm -rf /data/system/package_cache/*
  